---
name: Civic Cooperative Marketplace
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#3e4943'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#6e7a72'
  outline-variant: '#bdc9c1'
  surface-tint: '#006c4b'
  primary: '#005f41'
  on-primary: '#ffffff'
  primary-container: '#007a55'
  on-primary-container: '#a3ffd2'
  inverse-primary: '#79d9ad'
  secondary: '#855300'
  on-secondary: '#ffffff'
  secondary-container: '#fea619'
  on-secondary-container: '#684000'
  tertiary: '#005f40'
  on-tertiary: '#ffffff'
  tertiary-container: '#007a53'
  on-tertiary-container: '#a3ffd0'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#95f6c8'
  primary-fixed-dim: '#79d9ad'
  on-primary-fixed: '#002114'
  on-primary-fixed-variant: '#005137'
  secondary-fixed: '#ffddb8'
  secondary-fixed-dim: '#ffb95f'
  on-secondary-fixed: '#2a1700'
  on-secondary-fixed-variant: '#653e00'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 52px
    fontWeight: '800'
    lineHeight: 60px
    letterSpacing: -0.03em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 34px
    fontWeight: '800'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
  label-caps:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.08em
  metric-val:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '800'
    lineHeight: 32px
    letterSpacing: -0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  space-2xs: 0.25rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
  space-3xl: 4rem
  gutter-mobile: 1rem
  gutter-desktop: 1.5rem
  container-max: 1280px
---

## Brand & Style
This design system defines an ethical, human-first civic marketplace bridging local skilled service workers and neighborhood residents under a worker-owned cooperative federation. The visual style marries **Corporate / Modern** clarity with **Warm Civic Humanism**—eschewing cold corporate gig-economy aesthetics in favor of radical transparency, cooperative solidarity, and mutual dignity.

The design relies on:
- **Calm, high-trust clarity**: Ample breathable space, crisp typography, and unambiguous data representation (e.g., fair split breakdowns, welfare funds, verifiable IDs).
- **Tactile legitimacy**: Physical metaphors like physical-look cooperative ID badges, watermark stamps ("VERIFIED MEMBER"), and embossed certification tokens that evoke real-world trade credentialing.
- **Approachable empowerment**: Uplifting tonal greens balanced with warm golden accents, humanizing worker statistics while preserving industrial-grade usability.

## Colors
The color foundation communicates institutional credibility, prosperity, and shared social welfare:

- **Primary (`#007A55` / Deep Emerald & `#005A3E`)**: The anchor of the platform. Used for primary interactive triggers, institutional navigation headers, and hero cooperative statements. Conveys prosperity, stability, and ethical governance.
- **Secondary (`#F59E0B` / Warm Amber & `#D97706`)**: Represents livelihood, financial earnings, welfare reserve balances, and rating highlights. Provides optimism and warmth without signaling alarm or danger.
- **Tertiary & Accent (`#10B981` / Vibrant Mint & `#E6F7F0` / Mint Wash)**: Used for active verified badges, live online indicators, verified member stamps, and affirmative status indicators.
- **Dark Slate & Text (`#0F172A` / `#334155` / `#64748B`)**: High-legibility neutral scale for typography, high-contrast labels, and card headers.
- **Backgrounds & Tonal Canvas (`#F8FAFC` to `#F1F5F9`)**: Soft, clean surfaces that prevent optical fatigue while providing strong contrast against pure white (`#FFFFFF`) elevated cards.

## Typography
The system employs **Plus Jakarta Sans** throughout all hierarchical tiers to balance functional clarity with geometric warmth. 

- **Eyebrow Headers**: Rendered in `label-caps` with uppercase transformations, wide tracking (`0.08em`), and muted slate colors (`#64748B`), establishing section context cleanly.
- **Hero & Section Titles**: Use heavy font weights (`700` and `800`) with tighter negative tracking (`-0.02em` to `-0.03em`) for high impact and authoritative credibility.
- **Numerics & Ledger Values**: Metrics (earnings, wages, ratings) demand high tabular clarity; currency markers and integer sets use semi-bold or bold styles to convey transparent accounting.

## Layout & Spacing
A 12-column responsive fluid grid anchored by a `1280px` maximum viewport container.

- **Desktop (1024px+)**: 12 columns with `24px` (`1.5rem`) gutters and dynamic page margins. Service catalogs render in 4-column cards; dashboard feeds render in 8-column primary and 4-column sidebars.
- **Tablet (768px - 1023px)**: 8 columns with `16px` (`1rem`) gutters. Service cards shift to a 2-column or 3-column layout.
- **Mobile (< 768px)**: 4 columns with `16px` horizontal edge insets. Complex dashboard widgets stack vertically, giving the Worker ID Card and Welfare Breakdown full viewport width.
- **Vertical Spacing Cadence**: Follows a strict `8px` baseline grid. Compact card interiors use `space-sm` to `space-md`, while section boundaries maintain `space-2xl` to `space-3xl` for high clarity and uncrowded interaction.

## Elevation & Depth
Depth uses layered surfaces and diffused, low-opacity ambient shadows that mimic natural daylight over crisp white surfaces:

- **Surface Neutral (Canvas)**: `#F8FAFC`, non-elevated background plane.
- **Surface Elevation 1 (Cards, Lists)**: `#FFFFFF` with a border stroke of `1px solid #E2E8F0` and `box-shadow: 0 1px 3px 0 rgba(15, 23, 42, 0.04), 0 1px 2px -1px rgba(15, 23, 42, 0.02)`.
- **Surface Elevation 2 (Hover States, Interactive Cards)**: `box-shadow: 0 10px 15px -3px rgba(15, 23, 42, 0.06), 0 4px 6px -4px rgba(15, 23, 42, 0.03)` with a border shift to `#CBD5E1`.
- **Surface Elevation 3 (Overlays, Cooperative ID Card)**: Dual layer shadow with a cool slate undertone: `0 20px 25px -5px rgba(15, 23, 42, 0.08), 0 8px 10px -6px rgba(15, 23, 42, 0.03)`.
- **Tonal Identity Header**: Physical badge treatments (e.g., Worker Member Card) utilize an inverted dark container header (`#0F172A`) to evoke official credential cards.

## Shapes
A consistent `roundedness: 2` standard sets the base radius at `0.5rem` (`8px`):
- **Buttons, Text Inputs, and Micro Badges**: `0.5rem` (`8px`) for a sturdy, friendly, and practical feel.
- **Content Cards, Service Panels, and ID Badges (`rounded-lg` / `rounded-xl`)**: `1rem` to `1.25rem` (`16px` to `20px`), softening large surfaces and lending modern warmth.
- **Status Pills and Verification Tags**: Fully pill-shaped (`9999px`) to immediately indicate state and non-interactive status.

## Components

### Buttons & Interactive Triggers
- **Primary Button**: Solid `#007A55` fill, `#FFFFFF` text, `8px` corner radius, `12px 20px` padding. On hover: `#005A3E` with subtle lift.
- **Secondary / Outline Button**: Pure white background, `1px solid #CBD5E1` border, `#0F172A` text. Hover brings `#F8FAFC` surface and `#94A3B8` border.
- **Split Booking Trigger**: Paired action with standard rate preview (`from ₹299`) and embedded direct trigger button (`Book Service` / `View Profile`).

### Badges & Verification Seals
- **Verified Member Badge**: Pill or angled credential stamp with `1px solid #10B981`, `#E6F7F0` surface, and `#007A55` text with a checkmark icon.
- **Cooperative Member Header**: High-contrast dark charcoal header bar (`#0F172A`) across top of ID modules with golden amber caps labeling (`COOPERATIVE MEMBER`).
- **Category Filter Chips**: Pill-shaped filters in neutral `#FFFFFF` with muted borders, active state marked by dark emerald `#007A55` fill and white label.

### Data Displays & Cards
- **Cooperative Worker ID Card**: Modeled after physical union/trade credentials. Includes worker avatar, trade designation, verification tags, star rating with amber accents, job count, geographic jurisdiction, and official Member ID code (`SS-EL-0142`).
- **Fair-Split / Welfare Meter**: Linear multi-segment bar displaying pay distribution (e.g., `90% Worker Take-Home`, `10% Welfare Fund Reserve`), paired with clear rupee accounting.
- **Service Offering Cards**: Clean white surfaces displaying service icon enclosed in a soft emerald or mint circle, upfront pricing guarantee, concise service description, and nested direct CTA.

### Form Inputs & Search Fields
- **Global Service Search**: Large `48px` to `54px` height search bar with inset search icon, `#FFFFFF` background, subtle `#E2E8F0` border, and smooth focus ring in `#007A55`.